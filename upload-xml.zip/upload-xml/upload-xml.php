<?php 
/* 
Plugin Name: XML Import
Plugin URI: http://jsabarinath.wordpress.com
Version: 1.0
Author: Sabarinath J
Description: This is a custom plugin to import data via xml
*/
	add_action('admin_menu', 'xml_import_menu');
	function xml_import_menu(){
		add_menu_page('Import XML', 'Import Xml', 'manage_options', 'xml-data-import', 'xml_import', '', 62);
	}
	function xml_import(){
	?>
	<div class="wrap">
  <div id="icon-options-general" class="icon32"><br>
  </div>
  <h2>XML Upload</h2>
  <form enctype="multipart/form-data" name="frmRElect" action="<?php esc_url( $_SERVER['REQUEST_URI'] ); ?>" method="post">
   <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Upload XML" name="submit1">
  </form>
</div>
<?php
global $wpdb;
if(isset($_POST['submit1']))
{
//$uri = get_template_directory_uri().'/xmlupload/';
$uri = plugin_dir_path( __FILE__ );
//$uri = wp_upload_dir();
$target_dir = $uri;
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$filename = basename($_FILES["fileToUpload"]["name"]);
$filetypenew = wp_check_filetype($filename);
$uploadOk = 1;
$FileType = pathinfo($target_file,PATHINFO_EXTENSION);
//$FileType = pathinfo($filetype,PATHINFO_EXTENSION);

// Check if file already exists
if (file_exists($target_file)) {
    echo "<br/><br/>Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
    echo "<br/><br/>Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($FileType != "xml"  ) {
    echo "<br/><br/>Sorry, only XML files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "<br/><br/>Sorry, your file was not uploaded.";
	//echo "<br/>".$uri;
	//echo "<br/>".$target_file;
	//echo "<br/>file name is ".$filetypenew." file name is ".$filename;
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "<br/><br/>The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded successfully!!.";
		$xml=simplexml_load_file($target_file);
		foreach($xml->children() as $Customers){
			  global $wpdb;
			  $selquery = $wpdb->get_results("select id from wp_users where user_email='".$Customers->Email."'");
			  //echo $selquery;
              $selresult = mysql_query($selquery);
			  $selresultset = mysql_fetch_array($selresult);
			  if(mysql_num_rows($selquery)<=0)
			  {		 
              $uname = explode('@',$Customers->Email);
              $ulogin = $uname[0];
			  $data = array(
			  'user_login' => $ulogin,
			  'user_pass' => 'pass',
			  'user_nicename' => $Customers->Surname,
			  'user_email' => $Customers->Email,
			  'user_registered' => NOW(),
			  'display_name' => $Customers->FirstName,
			  'user_status' => 0,
			  );
			  $table_name = $wpdb->prefix . 'users';
			  // next line will insert the data
			  $wpdb->insert($table_name, $data, '%s'); 
			  
			  $userid = $wpdb->insert_id;
			  
			  echo "the inserted id is ".$userid;
			  
			  $table_name2 = $wpdb->prefix . 'usermeta';
			  
			  $data2 = array(
			  'user_id' => $userid,
			  'meta_key' => 'nick_name',
			  'meta_value' => $ulogin,
			  ); 
			  
			  $wpdb->insert($table_name2, $data2, '%s'); 
			  
			  $data3 = array(
			  'user_id' => $userid,
			  'meta_key' => 'first_name',
			  'meta_value' => $Customers->FirstName,
			  ); 
			  
			  $wpdb->insert($table_name2, $data3, '%s'); 
			 
			   $data4 = array(
			  'user_id' => $userid,
			  'meta_key' => 'last_name',
			  'meta_value' => $Customers->Surname,
			  ); 
			  
			  $wpdb->insert($table_name2, $data3, '%s'); 
			 
			   $data4 = array(
			  'user_id' => $userid,
			  'meta_key' => 'last_name',
			  'meta_value' => '',
			  ); 
			  
			  $wpdb->insert($table_name2, $data4, '%s'); 
			
			   $data5 = array(
			  'user_id' => $userid,
			  'meta_key' => 'description',
			  'meta_value' => '',
			  ); 
			  
			  $wpdb->insert($table_name2, $data5, '%s'); 
			
			   $data6 = array(
			  'user_id' => $userid,
			  'meta_key' => 'rich_editing',
			  'meta_value' => 'true',
			  ); 
			  
			  $wpdb->insert($table_name2, $data6, '%s'); 
			  
			   $data7 = array(
			  'user_id' => $userid,
			  'meta_key' => 'comment_shortcuts',
			  'meta_value' => 'false',
			  );
			  
			  $wpdb->insert($table_name2, $data7, '%s'); 
			
			 $data8 = array(
			  'user_id' => $userid,
			  'meta_key' => 'admin_color',
			  'meta_value' => 'fresh',
			  );
			  
			  $wpdb->insert($table_name2, $data8, '%s'); 
			
			$data9 = array(
			  'user_id' => $userid,
			  'meta_key' => 'use_ssl',
			  'meta_value' => 0,
			  );
			  
			  $wpdb->insert($table_name2, $data9, '%s'); 
			
			$data10 = array(
			  'user_id' => $userid,
			  'meta_key' => 'show_admin_bar_front',
			  'meta_value' => 'true',
			  );
			  
			  $wpdb->insert($table_name2, $data10, '%s'); 
			
			$data11 = array(
			  'user_id' => $userid,
			  'meta_key' => 'wp_capabilities',
			  'meta_value' => 'a:1:{s:8:customer;b:1;}',
			  );
			  
			  $wpdb->insert($table_name2, $data11, '%s'); 
			
			$data12 = array(
			  'user_id' => $userid,
			  'meta_key' => 'wp_user_level',
			  'meta_value' => 0,
			  );
			  
			  $wpdb->insert($table_name2, $data12, '%s'); 
			
			$data13 = array(
			  'user_id' => $userid,
			  'meta_key' => 'dismissed_wp_pointers',
			  'meta_value' => 'wp360_locks,wp390_widgets',
			  );
			  
			  $wpdb->insert($table_name2, $data13, '%s'); 
			
			$data14 = array(
			  'user_id' => $userid,
			  'meta_key' => 'session_tokens',
			  'meta_value' => '',
			  );
			  
			  $wpdb->insert($table_name2, $data14, '%s'); 
			
			$data15 = array(
			  'user_id' => $userid,
			  'meta_key' => 'author_facebook',
			  'meta_value' => '',
			  );
			  
			  $wpdb->insert($table_name2, $data15, '%s'); 
			
			$data16 = array(
			  'user_id' => $userid,
			  'meta_key' => 'author_twitter',
			  'meta_value' => '',
			  );
			  
			  $wpdb->insert($table_name2, $data16, '%s'); 
			  
			$data17 = array(
			  'user_id' => $userid,
			  'meta_key' => 'author_linkedin',
			  'meta_value' => '',
			  );
			  
			  $wpdb->insert($table_name2, $data17, '%s'); 
			  
    		$data18 = array(
			  'user_id' => $userid,
			  'meta_key' => 'author_dribble',
			  'meta_value' => '',
			  );
			  
			  $wpdb->insert($table_name2, $data18, '%s'); 
			
			$data18 = array(
			  'user_id' => $userid,
			  'meta_key' => 'author_gplus',
			  'meta_value' => '',
			  );
			  
			  $wpdb->insert($table_name2, $data18, '%s'); 
			
			$data19 = array(
			  'user_id' => $userid,
			  'meta_key' => 'author_custom',
			  'meta_value' => '',
			  );
			  
			  $wpdb->insert($table_name2, $data19, '%s'); 
			  
			$data20 = array(
			  'user_id' => $userid,
			  'meta_key' => 'billing_last_name',
			  'meta_value' => $Customers->Surname,
			  );
			  
			  $wpdb->insert($table_name2, $data20, '%s'); 
			
			$data21 = array(
			  'user_id' => $userid,
			  'meta_key' => 'billing_country',
			  'meta_value' => 'UK',
			  );
			  
			  $wpdb->insert($table_name2, $data21, '%s'); 
			
			$data22 = array(
			  'user_id' => $userid,
			  'meta_key' => 'billing_first_name',
			  'meta_value' => $Customers->FirstName,
			  );
			  
			  $wpdb->insert($table_name2, $data22, '%s'); 
			
			$data23 = array(
			  'user_id' => $userid,
			  'meta_key' => 'billing_address_1',
			  'meta_value' => $Customers->Address1,
			  );
			  
			  $wpdb->insert($table_name2, $data23, '%s'); 
			
			$data24 = array(
			  'user_id' => $userid,
			  'meta_key' => 'billing_address_2',
			  'meta_value' => $Customers->Address2,
			  );
			  
			  $wpdb->insert($table_name2, $data24, '%s'); 
			
			$data25 = array(
			  'user_id' => $userid,
			  'meta_key' => 'billing_city',
			  'meta_value' => $Customers->Address4,
			  );
			  
			  $wpdb->insert($table_name2, $data25, '%s'); 
			
			$data26 = array(
			  'user_id' => $userid,
			  'meta_key' => 'billing_state',
			  'meta_value' => $Customers->Address5,
			  );
			  
			  $wpdb->insert($table_name2, $data26, '%s');   
			
			$data27 = array(
			  'user_id' => $userid,
			  'meta_key' => 'billing_postcode',
			  'meta_value' => $Customers->PostCode,
			  );
			  
			  $wpdb->insert($table_name2, $data27, '%s');   
			
			$data28 = array(
			  'user_id' => $userid,
			  'meta_key' => 'billing_email',
			  'meta_value' => $Customers->Email,
			  );
			  
			  $wpdb->insert($table_name2, $data28, '%s');   
			
			$data29 = array(
			  'user_id' => $userid,
			  'meta_key' => 'billing_phone',
			  'meta_value' => $Customers->Telephone2,
			  );
			  
			  $wpdb->insert($table_name2, $data29, '%s');   
			
			$data30 = array(
			  'user_id' => $userid,
			  'meta_key' => 'billing_landline',
			  'meta_value' => $Customers->Telephone1,
			  );
			  
			  $wpdb->insert($table_name2, $data30, '%s');   
			
			$data31 = array(
			  'user_id' => $userid,
			  'meta_key' => 'billing_delivery_date',
			  'meta_value' => '',
			  );
			  
			  $wpdb->insert($table_name2, $data31, '%s');   
			
			$data32 = array(
			  'user_id' => $userid,
			  'meta_key' => 'billing_delivery_time',
			  'meta_value' => 'No Preference',
			  );
			  
			  $wpdb->insert($table_name2, $data32, '%s');   
			
			$data33 = array(
			  'user_id' => $userid,
			  'meta_key' => 'billing_nametitle',
			  'meta_value' => '',
			  );
			  
			  $wpdb->insert($table_name2, $data33, '%s');   
			
			  
			  if($Customers->AllowPhoneLandline=='Y' && $Customers->AllowPhoneMobile=='Y' && $Customers->AllowEmail=='Y' && $Customers->AllowEmailMarketing == 'Y' && $Customers->AllowSMS =='Y')
			  {
			  $data34 = array(
			  'user_id' => $userid,
			  'meta_key' => 'billing_subscription',
			  'meta_value' => 1,
			  );
			  
			  $wpdb->insert($table_name2, $data34, '%s');   
			
			  } else {
			    $data35 = array(
			  'user_id' => $userid,
			  'meta_key' => 'billing_subscription',
			  'meta_value' => 0,
			  );
			  
			  $wpdb->insert($table_name2, $data35, '%s');   
				
			  }
			    $data36 = array(
			  'user_id' => $userid,
			  'meta_key' => 'shipping_country',
			  'meta_value' => 'UK',
			  );
			  
			  $wpdb->insert($table_name2, $data36, '%s');   
				
				  $data37 = array(
			  'user_id' => $userid,
			  'meta_key' => 'shipping_address_1',
			  'meta_value' => $Customers->Address1,
			  );
			  
			  $wpdb->insert($table_name2, $data37, '%s');
			  
				  $data38 = array(
			  'user_id' => $userid,
			  'meta_key' => 'shipping_address_2',
			  'meta_value' => $Customers->Address2,
			  );
			  
			  $wpdb->insert($table_name2, $data38, '%s');
			  
				  $data38 = array(
			  'user_id' => $userid,
			  'meta_key' => 'shipping_city',
			  'meta_value' => $Customers->Address4,
			  );
			  
			  $wpdb->insert($table_name2, $data38, '%s');
			
				  $data39 = array(
			  'user_id' => $userid,
			  'meta_key' => 'shipping_state',
			  'meta_value' => $Customers->Address5,
			  );
			  
			  $wpdb->insert($table_name2, $data39, '%s');
			
				  $data40 = array(
			  'user_id' => $userid,
			  'meta_key' => 'shipping_postcode',
			  'meta_value' => $Customers->PostCode,
			  );
			  
			  $wpdb->insert($table_name2, $data40, '%s');
			
				  $data41 = array(
			  'user_id' => $userid,
			  'meta_key' => 'user_code',
			  'meta_value' => $Customers->Code,
			  );
			  
			  $wpdb->insert($table_name2, $data41, '%s');
			
				  $data42 = array(
			  'user_id' => $userid,
			  'meta_key' => 'shipping_route_code',
			  'meta_value' => $Customers->Route,
			  );
			  
			  $wpdb->insert($table_name2, $data42, '%s');
				
			 	  $data43 = array(
			  'user_id' => $userid,
			  'meta_key' => 'shipping_route_county',
			  'meta_value' => $Customers->County
			  );
			  
			  $wpdb->insert($table_name2, $data43, '%s');
			 
			 	  $data44 = array(
			  'user_id' => $userid,
			  'meta_key' => 'initials',
			  'meta_value' => $Customers->Initials
			  );
			  
			  $wpdb->insert($table_name2, $data44, '%s');
			  
			  } else 
			  {
				  //updation
			  $query = "update wp_users set user_nicename='".$Customers->Surname."',display_name='".$Customers->FirstName."'  where id='".$selresultset['id']."'";	
			
			  mysql_query($query);
			  
			  $query1 = "update wp_usermeta set meta_value='".$Customers->FirstName."' where user_id='".$selresultset['id']."' and meta_key='first_name'";	
			  mysql_query($query1);
			  
			  $query4 = "update wp_usermeta set meta_value='".$Customers->Surname."' where user_id='".$selresultset['id']."' and meta_key='last_name'";	
			  mysql_query($query4);
			  
			  $query2 = "update wp_usermeta set meta_value='".$Customers->Surname."' where user_id='".$selresultset['id']."' and meta_key='billing_last_name'";	
			  mysql_query($query2);
			  
			  $query3 = "update wp_usermeta set meta_value='".$Customers->FirstName."' where user_id='".$selresultset['id']."' and meta_key='billing_first_name'";	
			  mysql_query($query3);
			  
			   $query5 = "update wp_usermeta set meta_value='".$Customers->Address1."' where user_id='".$selresultset['id']."' and meta_key='billing_address_1'";	
			   mysql_query($query5);
			   
			  $query6 = "update wp_usermeta set meta_value='".$Customers->Address2."' where user_id='".$selresultset['id']."' and meta_key='billing_address_2'";	
			  mysql_query($query6);
			  
			  $query7 = "update wp_usermeta set meta_value='".$Customers->Address4."' where user_id='".$selresultset['id']."' and meta_key='billing_city'";	
			  mysql_query($query7);
			  
			   $query8 = "update wp_usermeta set meta_value='".$Customers->Address5."' where user_id='".$selresultset['id']."' and meta_key='billing_state'";	
			  mysql_query($query8);
			  
			  $query11 = "update wp_usermeta set meta_value='".$Customers->PostCode."' where user_id='".$selresultset['id']."' and meta_key='billing_postcode'";	
			  mysql_query($query11);
			  
			   $query12 = "update wp_usermeta set meta_value='".$Customers->Telephone2."' where user_id='".$selresultset['id']."' and meta_key='billing_phone'";	
			  mysql_query($query12);
			  
			   $query13 = "update wp_usermeta set meta_value='".$Customers->Telephone1."' where user_id='".$selresultset['id']."' and meta_key='billing_landline'";	
			  mysql_query($query13);
			  
			  if($Customers->AllowPhoneLandline=='Y' && $Customers->AllowPhoneMobile=='Y' && $Customers->AllowEmail=='Y' && $Customers->AllowEmailMarketing == 'Y' && $Customers->AllowSMS =='Y')
			  {
				  $query9 = "update wp_usermeta set meta_value='1' where user_id='".$selresultset['id']."' and meta_key='billing_subscription'";
			      mysql_query($query9);
			  } else {
				   $query9 = "update wp_usermeta set meta_value='0' where user_id='".$selresultset['id']."' and meta_key='billing_subscription'";
			      mysql_query($query9);
			  }
			  
			   $query10 = "update wp_usermeta set meta_value='".$Customers->Address1."' where user_id='".$selresultset['id']."' and meta_key='shipping_address_1'";	
			   mysql_query($query10);
			   
			   $query22 = "update wp_usermeta set meta_value='".$Customers->Address2."' where user_id='".$selresultset['id']."' and meta_key='shipping_address_2'";	
			   mysql_query($query22);
			   
			    $query23 = "update wp_usermeta set meta_value='".$Customers->Address4."' where user_id='".$selresultset['id']."' and meta_key='shipping_city'";	
			   mysql_query($query23);
			   
			   $query24 = "update wp_usermeta set meta_value='".$Customers->Address5."' where user_id='".$selresultset['id']."' and meta_key='shipping_state'";	
			   mysql_query($query24);
			   
			   $query25 = "update wp_usermeta set meta_value='".$Customers->PostCode."' where user_id='".$selresultset['id']."' and meta_key='shipping_postcode'";	
			   mysql_query($query25);
			   
			    $query26 = "update wp_usermeta set meta_value='".$Customers->Code."' where user_id='".$selresultset['id']."' and meta_key='user_code'";	
			   mysql_query($query26);
			  
			   $query14 = "update wp_usermeta set meta_value='".$Customers->Route."' where user_id='".$selresultset['id']."' and meta_key='shipping_route_code'";	
			  mysql_query($query14);
			  
			   $query15 = "update wp_usermeta set meta_value='".$Customers->County."' where user_id='".$selresultset['id']."' and meta_key='shipping_route_county'";	
			  mysql_query($query15);
			  
			  $query21 = "update wp_usermeta set meta_value='".$Customers->Initials."' where user_id='".$selresultset['id']."' and meta_key='initials'";	
			  mysql_query($query21);
			  }
			}
		// deleting the file
		unlink($target_file);
		/* end storing in db */
		//redirecting
		wp_redirect(admin_url('/post-new.php?admin.php?page=xml-data-import', 'http'), 301);
		//end redirecting
    } else {
        echo "<br/><br/>Sorry, there was an error uploading your file.";
    }
}
}
?>
<?php } ?>